import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class FirebaseHelper {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static final String _collection = "mood_entries";

  /// Save today's mood ("Good" or "Sad") with current timestamp
  static Future<void> saveMood(String mood) async {
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());

    await _firestore.collection(_collection).doc(today).set({
      'mood': mood,
      'timestamp': FieldValue.serverTimestamp(),
    });

    print("✅ Mood saved: $mood on $today");
  }

  /// Fetch last 3 mood entries (latest first)
  static Future<List<String>> getLastThreeMoods() async {
    final snapshot = await _firestore
        .collection(_collection)
        .orderBy('timestamp', descending: true)
        .limit(3)
        .get();

    List<String> moods = snapshot.docs.map<String>((doc) {
      return doc['mood'] ?? 'Good';
    }).toList();

    print("📊 Last 3 moods: $moods");
    return moods.reversed.toList(); // Oldest first for consistency
  }

  /// Get mood pattern string like "GBG" based on last 3 moods
  static Future<String> getMoodPatternCode() async {
    final moods = await getLastThreeMoods();
    final pattern = moods.map((m) => m.toLowerCase() == 'good' ? 'G' : 'B').join();
    print("🧠 Mood Pattern: $pattern");
    return pattern;
  }

  /// Return both the list of moods and their pattern code
  static Future<Map<String, dynamic>> getMoodData() async {
    final moods = await getLastThreeMoods();
    final pattern = moods.map((m) => m.toLowerCase() == 'good' ? 'G' : 'B').join();
    return {
      'moodList': moods,
      'patternCode': pattern,
    };
  }

  /// Save a mood pattern (like GGB, BGG) with current timestamp
  static Future<void> saveMoodPattern(List<String> moods) async {
    final pattern = moods.map((m) => m.toLowerCase() == 'good' ? 'G' : 'B').join();
    final timestamp = FieldValue.serverTimestamp();

    await _firestore.collection("mood_patterns").add({
      "pattern": pattern,
      "timestamp": timestamp,
    });

    print("✅ Mood pattern '$pattern' saved to Firestore");
  }

  /// Save both individual mood and corresponding pattern
  static Future<void> saveMoodAndPattern(String mood) async {
    await saveMood(mood);
    final lastThree = await getLastThreeMoods();
    if (lastThree.length == 3) {
      await saveMoodPattern(lastThree);
    }
  }
}
